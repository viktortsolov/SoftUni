﻿namespace WildFarm.Contracts
{
    public interface IAskable
    {
        string AskForFood();
    }
}
