﻿namespace WildFarm.Common
{
    public class ExceptionMessages
    {
        public const string DIFF_TYPE_OF_FOOD_EXC_MSG = "{0} does not eat {1}!";
        public const string INVALID_FOOD_TYPE = "Invalid food type!";
        public const string INVALID_ANIMAL_TYPE = "Invalid animal type!";
    }
}
