﻿namespace Heroes.Common
{
    public class ExceptionMessages
    {
        public const string INVALID_HERO_EXC_MSG = "Invalid hero!";
    }
}
