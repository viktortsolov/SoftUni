﻿namespace Heroes.Common
{
    public class Messages
    {
        public const string DRUID_AND_PALADIN_MSG = "{0} - {1} healed for {2}";
        public const string ROGUE_AND_WARRIOR_MSG = "{0} - {1} hit for {2} damage";
    }
}
