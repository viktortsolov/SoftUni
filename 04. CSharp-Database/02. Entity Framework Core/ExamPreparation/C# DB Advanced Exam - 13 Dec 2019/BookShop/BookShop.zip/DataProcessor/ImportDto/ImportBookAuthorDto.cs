﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportBookAuthorDto
    {
        public string Id { get; set; }
    }
}