﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-J9T9LVF\MSSQLSERVER01;Integrated Security=true;Database=SoftUni";
    }
}
