﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-J9T9LVF\MSSQLSERVER01;Database=MusicHub;Trusted_Connection=True";
    }
}
