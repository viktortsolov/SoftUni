﻿namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string CONNECTION_STRING = @"Server=DESKTOP-J9T9LVF\MSSQLSERVER01;Integrated Security=true;Database=FootballBettingSystem";
    }
}
