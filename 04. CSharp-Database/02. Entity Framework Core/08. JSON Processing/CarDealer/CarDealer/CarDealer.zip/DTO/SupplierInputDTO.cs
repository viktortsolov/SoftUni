﻿namespace CarDealer.DTO
{
    public class SupplierInputDTO
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
