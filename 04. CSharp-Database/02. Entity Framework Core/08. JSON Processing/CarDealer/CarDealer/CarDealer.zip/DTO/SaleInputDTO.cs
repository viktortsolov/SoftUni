﻿namespace CarDealer.DTO
{
    public class SaleInputDTO
    {
        public int CarId { get; set; }
        public int CustomerId { get; set; }
        public int Discound { get; set; }
    }
}
