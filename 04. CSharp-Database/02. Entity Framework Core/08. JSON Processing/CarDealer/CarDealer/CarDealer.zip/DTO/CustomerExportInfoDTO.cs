﻿using System;

namespace CarDealer.DTO
{
    internal class CustomerExportInfoDTO
    {
        public string Name { get; set; }

        public DateTime BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
